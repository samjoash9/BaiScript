#include "semantic_analyzer.h"
#include "ast.h"
#include "symbol_table.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <ctype.h>

/* ----------------------------
Internal structures
---------------------------- */

static SEM_TEMP *sem_temps = NULL;
static size_t sem_temps_capacity = 0;
static size_t sem_temps_count = 0;
static int sem_next_temp_id = 1;

static SEM_OP *sem_ops = NULL;
static size_t sem_ops_capacity = 0;
static size_t sem_ops_count = 0;

static KnownVar *known_vars_head = NULL;

static int sem_errors = 0;
static int sem_warnings = 0;
static int sem_inside_print = 0; // 1 if evaluating inside a PRENT

static FILE *out_file = NULL;

/* Deferred postfix ops (kept for possible future policy changes) */
typedef struct DeferredOp
{
    KnownVar *kv;
    int delta; // +1 for ++, -1 for --
    struct DeferredOp *next;
} DeferredOp;

static DeferredOp *deferred_head = NULL;

/* ----------------------------
Helpers: error/warning
---------------------------- */

static void sem_record_error(ASTNode *node, const char *fmt, ...)
{
    sem_errors++;

    if (!out_file)
        return;

    fprintf(out_file, "ERROR: ");

    va_list ap;
    va_start(ap, fmt);
    vfprintf(out_file, fmt, ap);
    va_end(ap);

    if (node)
        fprintf(out_file, " [line:%d]\n", node->line);
}

static void sem_record_warning(ASTNode *node, const char *fmt, ...)
{
    sem_warnings++;

    if (!out_file)
        return;

    va_list ap;
    va_start(ap, fmt);
    vfprintf(out_file, fmt, ap);
    va_end(ap);

    if (node)
        fprintf(out_file, " [line:%d]\n", node->line);
}

/* ----------------------------
Dynamic arrays helpers
---------------------------- */

static int ensure_temp_capacity(void)
{
    if (sem_temps_count + 1 > sem_temps_capacity)
    {
        size_t newcap = sem_temps_capacity == 0 ? 256 : sem_temps_capacity * 2;
        SEM_TEMP *nb = (SEM_TEMP *)realloc(sem_temps, newcap * sizeof(SEM_TEMP));
        if (!nb)
            return 0;
        sem_temps = nb;
        sem_temps_capacity = newcap;
    }
    return 1;
}

static int ensure_ops_capacity(void)
{
    if (sem_ops_count + 1 > sem_ops_capacity)
    {
        size_t newcap = sem_ops_capacity == 0 ? 256 : sem_ops_capacity * 2;
        SEM_OP *nb = (SEM_OP *)realloc(sem_ops, newcap * sizeof(SEM_OP));
        if (!nb)
            return 0;
        sem_ops = nb;
        sem_ops_capacity = newcap;
    }
    return 1;
}

/* ----------------------------
Deferred postfix helpers
(retained but not used for current immediate semantics)
---------------------------- */
static void push_deferred_op(KnownVar *kv, int delta)
{
    DeferredOp *d = (DeferredOp *)malloc(sizeof(DeferredOp));
    if (!d)
        return;
    d->kv = kv;
    d->delta = delta;
    d->next = deferred_head;
    deferred_head = d;
}

static void apply_deferred_ops(void)
{
    if (!deferred_head)
        return;

    // Reverse the list for FIFO
    DeferredOp *prev = NULL, *cur = deferred_head;
    while (cur)
    {
        DeferredOp *n = cur->next;
        cur->next = prev;
        prev = cur;
        cur = n;
    }
    DeferredOp *r = prev;

    for (DeferredOp *p = r; p; p = p->next)
    {
        KnownVar *kv = p->kv;
        if (!kv)
            continue;
        if (!kv->initialized)
        {
            sem_record_error(kv->temp.node, "Postfix operation on uninitialized variable '%s'", kv->name);
            continue;
        }
        long before = kv->temp.is_constant ? kv->temp.int_value : 0;
        long after = before + p->delta;
        kv->temp.is_constant = 1;
        kv->temp.int_value = after;
        kv->initialized = 1;
        kv->used = 1;

        int idx = find_symbol(kv->name);
        if (idx != -1)
        {
            symbol_table[idx].initialized = 1;
            snprintf(symbol_table[idx].value_str, SYMBOL_VALUE_MAX, "%ld", after);
        }
    }

    // free list
    DeferredOp *it = r;
    while (it)
    {
        DeferredOp *n = it->next;
        free(it);
        it = n;
    }
    deferred_head = NULL;
}

/* ----------------------------
Public helpers
---------------------------- */

SEM_TEMP sem_new_temp(SEM_TYPE type)
{
    if (!ensure_temp_capacity())
    {
        SEM_TEMP t = {0, SEM_TYPE_UNKNOWN, 0, 0, NULL};
        return t;
    }
    SEM_TEMP t;
    t.id = sem_next_temp_id++;
    t.type = type;
    t.is_constant = 0;
    t.int_value = 0;
    t.node = NULL;
    sem_temps[sem_temps_count++] = t;
    return t;
}

KnownVar *sem_find_var(const char *name)
{
    for (KnownVar *k = known_vars_head; k; k = k->next)
        if (strcmp(k->name, name) == 0)
            return k;
    return NULL;
}

KnownVar *sem_add_var(const char *name, SEM_TYPE type)
{
    /* If already present, return existing KnownVar (do not treat as error here). */
    KnownVar *existing = sem_find_var(name);
    if (existing)
        return existing;

    KnownVar *k = (KnownVar *)malloc(sizeof(KnownVar));
    if (!k)
        return NULL;
    k->name = strdup(name);
    if (!k->name) { free(k); return NULL; }
    k->temp = sem_new_temp(type);
    k->used = 0;
    k->next = known_vars_head;
    known_vars_head = k;

    if (type == SEM_TYPE_INT || type == SEM_TYPE_CHAR) {
        k->initialized = 1;
        k->temp.is_constant = 1;
        k->temp.int_value = 0;
    } else {
        k->initialized = 0; // KUAN starts uninitialized
    }

    const char *dtype_str = "KUAN";
    if (type == SEM_TYPE_INT) dtype_str = "ENTEGER";
    else if (type == SEM_TYPE_CHAR) dtype_str = "CHAROT";

    int idx = find_symbol(name);
    if (idx == -1)
        add_symbol(name, dtype_str, k->initialized, k->initialized ? NULL : NULL);

    return k;
}


SEM_TYPE sem_type_from_string(const char *s)
{
    if (!s)
        return SEM_TYPE_UNKNOWN;
    if (strcmp(s, "ENTEGER") == 0 || strcmp(s, "int") == 0)
        return SEM_TYPE_INT;
    if (strcmp(s, "CHAROT") == 0 || strcmp(s, "char") == 0)
        return SEM_TYPE_CHAR;
    if (strcmp(s, "KUAN") == 0)
        return SEM_TYPE_UNKNOWN;
    return SEM_TYPE_UNKNOWN;
}

/* ----------------------------
Constant helpers
---------------------------- */

static int try_parse_int(const char *s, long *out)
{
    if (!s || !out)
        return 0;
    char *end;
    long v = strtol(s, &end, 10);
    if (end != s && *end == '\0')
    {
        *out = v;
        return 1;
    }
    return 0;
}

static int try_parse_char_literal(const char *lex, long *out)
{
    if (!lex || !out)
        return 0;
    size_t len = strlen(lex);
    if (len < 3 || lex[0] != '\'' || lex[len - 1] != '\'')
        return 0;
    size_t content_len = len - 2;
    if (content_len == 1)
    {
        *out = (unsigned char)lex[1];
        return 1;
    }
    if (content_len == 2 && lex[1] == '\\')
    {
        char esc = lex[2];
        switch (esc)
        {
        case 'n':
            *out = '\n';
            return 1;
        case 't':
            *out = '\t';
            return 1;
        case 'r': // no proper logic yet
            *out = '\r';
        case '0':
            *out = '\0';
            return 1;
        case '\\':
            *out = '\\';
            return 1;
        case '\'':
            *out = '\'';
            return 1;
        case '"':
            *out = '"';
            return 1;
        default:
            return 0;
        }
    }
    return 0;
}

/* ----------------------------
Expression evaluation
---------------------------- */

static SEM_TEMP evaluate_expression(ASTNode *node);
static SEM_TEMP eval_factor(ASTNode *node);
static SEM_TEMP eval_term(ASTNode *node);
static SEM_TEMP eval_additive(ASTNode *node);

static SEM_TEMP eval_factor(ASTNode *node)
{
    if (!node)
        return sem_new_temp(SEM_TYPE_UNKNOWN);

    if (node->type == NODE_LITERAL)
    {
        long v;
        SEM_TEMP t;
        if (try_parse_int(node->value, &v))
        {
            t = sem_new_temp(SEM_TYPE_INT);
            t.is_constant = 1;
            t.int_value = v;
            t.node = node;
            return t;
        }
        if (try_parse_char_literal(node->value, &v))
        {
            t = sem_new_temp(SEM_TYPE_CHAR);
            t.is_constant = 1;
            t.int_value = v;
            t.node = node;
            return t;
        }
        return sem_new_temp(SEM_TYPE_UNKNOWN);
    }

    if (node->type == NODE_IDENTIFIER)
    {
        const char *name = node->value;
        if (!name)
            return sem_new_temp(SEM_TYPE_UNKNOWN);

        KnownVar *kv = sem_find_var(name);
        if (kv)
        {
            kv->used = 1; // mark as used
            if (sem_inside_print)
                kv->used = 1; // redundant but explicit
            if (!kv->initialized)
                sem_record_error(node, "Use of uninitialized variable '%s'", name);
            SEM_TEMP t = kv->temp;
            t.node = node;
            return t;
        }

        int idx = find_symbol(name);
        if (idx == -1)
        {
            sem_record_error(node, "Undeclared identifier '%s'", name);
            return sem_new_temp(SEM_TYPE_UNKNOWN);
        }

        SEM_TYPE stype = sem_type_from_string(symbol_table[idx].datatype);
        SEM_TEMP placeholder = sem_new_temp(stype);
        placeholder.node = node;

        KnownVar *new_kv = sem_add_var(name, stype);
        new_kv->used = 1;
        new_kv->initialized = symbol_table[idx].initialized;
        if (symbol_table[idx].initialized)
        {
            long vv = 0;
            if (try_parse_int(symbol_table[idx].value_str, &vv))
            {
                new_kv->temp.is_constant = 1;
                new_kv->temp.int_value = vv;
            }
        }
        return placeholder;
    }

    return evaluate_expression(node);
}

static SEM_TEMP eval_term(ASTNode *node)
{
    if (!node)
        return sem_new_temp(SEM_TYPE_UNKNOWN);
    if (node->type != NODE_TERM)
        return eval_factor(node);

    if (!node->left || !node->right)
    {
        if (node->left)  evaluate_expression(node->left);
        if (node->right) evaluate_expression(node->right);
        return sem_new_temp(SEM_TYPE_UNKNOWN);
    }

    SEM_TEMP L = eval_term(node->left);
    SEM_TEMP R = eval_factor(node->right);
    const char *op = node->value ? node->value : "";

    long val = 0;
    SEM_TYPE result_type = SEM_TYPE_INT;

    // -----------------------------
    // TYPE RESOLUTION (same as additive)
    // -----------------------------
    if (L.type == SEM_TYPE_CHAR && R.type == SEM_TYPE_CHAR)
        result_type = SEM_TYPE_CHAR;
    else if (L.type == SEM_TYPE_CHAR && R.type == SEM_TYPE_INT)
        result_type = SEM_TYPE_CHAR;
    else if (L.type == SEM_TYPE_INT && R.type == SEM_TYPE_CHAR)
        result_type = SEM_TYPE_INT;
    else
        result_type = SEM_TYPE_INT;

    // -----------------------------
    // CONSTANT FOLDING (if possible)
    // -----------------------------
    if (L.is_constant && R.is_constant && op[0] != '\0')
    {
        if (strcmp(op, "*") == 0)
        {
            val = L.int_value * R.int_value;
        }
        else if (strcmp(op, "/") == 0)
        {
            if (R.int_value == 0)
            {
                sem_record_error(node, "Division by zero");
                val = 0;
            }
            else
            {
                val = L.int_value / R.int_value;
            }
        }
    }

    // -----------------------------
    // RESULT TEMP
    // -----------------------------
    SEM_TEMP t = sem_new_temp(result_type);
    t.node = node;
    t.is_constant = (L.is_constant && R.is_constant);
    t.int_value = val;
    t.type = result_type;

    return t;
}

static SEM_TEMP eval_additive(ASTNode *node)
{
    if (!node)
        return sem_new_temp(SEM_TYPE_UNKNOWN);
    if (node->type != NODE_EXPRESSION)
        return eval_term(node);

    if (!node->left || !node->right)
    {
        if (node->left)
            evaluate_expression(node->left);
        if (node->right)
            evaluate_expression(node->right);
        return sem_new_temp(SEM_TYPE_UNKNOWN);
    }

    SEM_TEMP L = eval_additive(node->left);
    SEM_TEMP R = eval_term(node->right);
    const char *op = node->value ? node->value : "";

    long val = 0;
    SEM_TYPE result_type = SEM_TYPE_INT;

    // Determine result type based on operand types
    if (L.type == SEM_TYPE_CHAR && R.type == SEM_TYPE_CHAR)
        result_type = SEM_TYPE_CHAR;       // CHAR + CHAR
    else if (L.type == SEM_TYPE_CHAR && R.type == SEM_TYPE_INT)
        result_type = SEM_TYPE_CHAR;       // CHAR + INT → CHAR
    else if (L.type == SEM_TYPE_INT && R.type == SEM_TYPE_CHAR)
        result_type = SEM_TYPE_INT;        // INT + CHAR → INT
    else
        result_type = SEM_TYPE_INT;        // INT + INT or unknown

    // Constant folding if possible
    if (L.is_constant && R.is_constant)
    {
        if (strcmp(op, "+") == 0)
            val = L.int_value + R.int_value;
        else if (strcmp(op, "-") == 0)
            val = L.int_value - R.int_value;
        else
            val = 0; // fallback
    }

    SEM_TEMP t = sem_new_temp(result_type);
    t.is_constant = (L.is_constant && R.is_constant);
    t.int_value = val;
    t.node = node;
    t.type = result_type;

    return t;
}


static SEM_TEMP evaluate_expression(ASTNode *node)
{
    if (!node)
        return sem_new_temp(SEM_TYPE_UNKNOWN);

    switch (node->type)
    {
    case NODE_TERM:
        return eval_term(node);
    case NODE_EXPRESSION:
        return eval_additive(node);
    case NODE_UNARY_OP:
    {
        // prefix operators: e.g. ++a, --a, unary -
        const char *op = node->value ? node->value : "";
        if (op && (strcmp(op, "++") == 0 || strcmp(op, "--") == 0))
        {
            ASTNode *target = node->left;
            if (!target || target->type != NODE_IDENTIFIER)
            {
                sem_record_error(node, "Prefix %s applied to non-identifier", op);
                return sem_new_temp(SEM_TYPE_UNKNOWN);
            }
            const char *name = target->value;
            KnownVar *kv = sem_find_var(name);
            if (kv && sem_inside_print)
                kv->used = 1;
            if (!kv)
                kv = sem_add_var(name, SEM_TYPE_INT);
            if (!kv->initialized)
            {
                sem_record_error(target, "Prefix %s on uninitialized variable '%s'", op, name);
                // but still mark initialized and continue
                kv->initialized = 1;
                kv->temp.is_constant = 1;
                kv->temp.int_value = 0;
            }
            int delta = (strcmp(op, "++") == 0) ? 1 : -1;
            long newval = (kv->temp.is_constant ? kv->temp.int_value : 0) + delta;
            kv->temp.is_constant = 1;
            kv->temp.int_value = newval;
            kv->initialized = 1;

            int idx = find_symbol(kv->name);
            if (idx != -1)
            {
                symbol_table[idx].initialized = 1;
                snprintf(symbol_table[idx].value_str, SYMBOL_VALUE_MAX, "%ld", newval);
            }

            SEM_TEMP r = sem_new_temp(kv->temp.type);
            r.is_constant = 1;
            r.int_value = newval;
            r.node = node;
            return r;
        }
        // unary minus and other unary ops
        {
            SEM_TEMP t = evaluate_expression(node->left);
            if (t.is_constant && op && op[0] != '\0' && strcmp(op, "-") == 0)
            {
                SEM_TEMP r = sem_new_temp(t.type);
                r.is_constant = 1;
                r.int_value = -t.int_value;
                r.node = node;
                return r;
            }
            return t;
        }
    }
    case NODE_POSTFIX_OP: {
        const char *op = node->value ? node->value : "";
        ASTNode *target = node->left;
        if (!target || target->type != NODE_IDENTIFIER) {
            sem_record_error(node, "Postfix %s applied to non-identifier", op);
            return sem_new_temp(SEM_TYPE_UNKNOWN);
        }

        const char *name = target->value;
        KnownVar *kv = sem_find_var(name);
        if (!kv) {
            sem_record_error(node, "Use of undeclared variable '%s'", name);
            return sem_new_temp(SEM_TYPE_UNKNOWN);
        }
        if (!kv->initialized)
            sem_record_error(target, "Use of uninitialized variable '%s' in postfix", name);

        SEM_TEMP ret = kv->temp; // return current value
        ret.node = node;

        // Determine delta
        int delta = 0;
        if (strcmp(op, "++") == 0) delta = 1;
        else if (strcmp(op, "--") == 0) delta = -1;

        // **Defer the delta instead of applying immediately**
        if (delta != 0)
            push_deferred_op(kv, delta);

        return ret;  // return old value
    }
    case NODE_ASSIGNMENT:
    {
        ASTNode *lhs = node->left;
        ASTNode *rhs = node->right;

        if (!lhs || lhs->type != NODE_IDENTIFIER) {
            sem_record_error(node, "Left side of assignment is not an identifier");
            return sem_new_temp(SEM_TYPE_UNKNOWN);
        }

        const char *name = lhs->value;
        KnownVar *kv = sem_add_var(name, SEM_TYPE_INT);

        const char *op = node->value ? node->value : "=";

        // Evaluate RHS expression first
        SEM_TEMP rval = evaluate_expression(rhs);

        long oldval = 0;
        if (strcmp(op, "=") != 0)   // compound assignment requires reading old value
        {
            if (!kv->initialized)
                sem_record_error(node, "Use of uninitialized variable '%s' in compound assignment", name);

            oldval = kv->temp.is_constant ? kv->temp.int_value : 0;
        }

        long newval = rval.int_value;

        // Handle compound operators
        if      (strcmp(op, "+=") == 0) newval = oldval + rval.int_value;
        else if (strcmp(op, "-=") == 0) newval = oldval - rval.int_value;
        else if (strcmp(op, "*=") == 0) newval = oldval * rval.int_value;
        else if (strcmp(op, "/=") == 0) {
            if (rval.int_value == 0)
                sem_record_error(node, "Division by zero");
            else
                newval = oldval / rval.int_value;
        }
        else if (strcmp(op, "=") == 0) {
            // simple assignment, already handled
        }
        else {
            sem_record_error(node, "Unknown assignment operator '%s'", op);
        }

        // Assign result
        kv->initialized = 1;
        kv->temp.is_constant = 1;
        kv->temp.int_value = newval;

        int idx = find_symbol(name);
        if (idx != -1) {
            symbol_table[idx].initialized = 1;
            snprintf(symbol_table[idx].value_str, SYMBOL_VALUE_MAX, "%ld", newval);
        }

        SEM_TEMP ret = sem_new_temp(SEM_TYPE_INT);
        ret.is_constant = 1;
        ret.int_value = newval;
        ret.node = node;

        return ret;
    }

    case NODE_IDENTIFIER:
    case NODE_LITERAL:
        return eval_factor(node);
    default:
        if (node->left)
            evaluate_expression(node->left);
        if (node->right)
            evaluate_expression(node->right);
        return sem_new_temp(SEM_TYPE_UNKNOWN);
    }
}

/* ----------------------------
Buffers for output
---------------------------- */
#define PRINT_BUFFER_SIZE 8192
static char print_buffer[PRINT_BUFFER_SIZE];
static size_t print_offset = 0;

static void buffer_print(const char *s)
{
    if (!s)
        return;
    size_t len = strlen(s);
    if (print_offset + len < PRINT_BUFFER_SIZE - 2)
    {
        strcpy(print_buffer + print_offset, s);
        print_offset += len;
    }
}


/* Unescape C-like escape sequences from src into dst.
Supports: \n, \t, \r, \0, \\, \", \', and simple unknown-escape passthrough.
dstsize is total buffer size for dst (including null).
*/
static void unescape_string(const char *src, char *dst, size_t dstsize)
{
    if (!src || !dst || dstsize == 0) return;
    size_t i = 0, j = 0;
    while (src[i] != '\0' && j + 1 < dstsize) /* leave room for null */
    {
        if (src[i] == '\\')
        {
            i++;
            if (src[i] == '\0') break;
            char c = src[i];
            switch (c)
            {
                case 'n': dst[j++] = '\n'; break;
                case 't': dst[j++] = '\t'; break;
                case 'r': dst[j++] = '\r'; break;
                case '0': dst[j++] = '\0'; break;
                case '\\': dst[j++] = '\\'; break;
                case '"': dst[j++] = '"'; break;
                case '\'': dst[j++] = '\''; break;
                default:
                    /* unknown escape: copy char as-is (e.g. \z -> z) */
                    dst[j++] = c;
                    break;
            }
            i++;
        }
        else
        {
            dst[j++] = src[i++];
        }
    }
    dst[j] = '\0';
}


/* ----------------------------
Handle print statements (printf-like)
---------------------------- */
static void handle_print(ASTNode *print_node)
{
    if (!print_node)
        return;

    sem_inside_print = 1; // Begin print context

    ASTNode *item = print_node->left;
    while (item)
    {
        ASTNode *expr = item->left ? item->left : item;

        if (expr->type == NODE_STRING_LITERAL) {
            const char *s = expr->value;
            size_t len = s ? strlen(s) : 0;

            if (len >= 2) {
                /* copy inner content (between the quotes) into a temporary buffer */
                char raw[1024];
                size_t content_len = len - 2;
                if (content_len >= sizeof(raw))
                    content_len = sizeof(raw) - 1;

                strncpy(raw, s + 1, content_len);
                raw[content_len] = '\0';

                /* unescape into another buffer and then print */
                char unesc[1024];
                unescape_string(raw, unesc, sizeof(unesc));
                buffer_print(unesc);
            }

            item = item->right;
            continue;
        }

        char tempbuf[1024] = {0};

        // Evaluate expression
        SEM_TEMP val = evaluate_expression(expr);
        
        // If identifier, update usage
        if (expr->type == NODE_IDENTIFIER)
        {
            KnownVar *kv = sem_find_var(expr->value);
            if (kv)
                kv->used = 1;
        }

        // Decide how to print based on actual variable type
        if (val.type == SEM_TYPE_CHAR)
        {
            tempbuf[0] = (char)val.int_value;
            tempbuf[1] = '\0';
        }
        else if (val.type == SEM_TYPE_INT)
        {
            snprintf(tempbuf, sizeof(tempbuf), "%ld", val.int_value);
        }
        else
        {
            // Fallback for KUAN / unknown: print integer
            snprintf(tempbuf, sizeof(tempbuf), "%ld", val.int_value);
        }

        buffer_print(tempbuf);

        // Move to next item in list (comma-separated)
        item = item->right;
    }

    buffer_print("\n"); // Append newline at end of PRENT
    sem_inside_print = 0; // End print context
}


/* ----------------------------
Declaration & assignment
---------------------------- */
void handle_declaration(ASTNode *decl_node, SEM_TYPE dtype)
{
    if (!decl_node)
        return;

    /* Simple identifier declaration */
    if (decl_node->type == NODE_IDENTIFIER)
    {
        const char *name = decl_node->value;
        KnownVar *existing = sem_find_var(name);

        /* Any existing declaration = ERROR */
        if (existing)
        {
            sem_record_error(decl_node,
                "Duplicate declaration of variable '%s'", name);
            return;
        }

        /* Also check symbol table (already-declared globally) */
        if (find_symbol(name) != -1)
        {
            sem_record_error(decl_node,
                "Duplicate declaration of variable '%s'", name);
            return;
        }

        /* Create new variable */
        KnownVar *kv = sem_add_var(name, dtype);
        if (!kv)
        {
            sem_record_error(decl_node,
                "Failed to declare variable '%s'", name);
            return;
        }

        kv->temp.type = dtype; // store declared type

        /* Default initialization for typed variables */
        if (dtype == SEM_TYPE_INT || dtype == SEM_TYPE_CHAR)
        {
            kv->temp.is_constant = 1;
            kv->temp.int_value = 0;
            kv->initialized = 1;
        }

        return;
    }

    /* Initialized declaration: IDENT = EXPR */
    if (decl_node->type == NODE_DECLARATION && strcmp(decl_node->value, "INIT_DECL") == 0)
    {
        const char *name = decl_node->left->value;
        ASTNode *init_expr = decl_node->right;

        /* If already declared (in known vars or symbol table), it's an error */
        if (sem_find_var(name) || find_symbol(name) != -1) {
            sem_record_error(decl_node, "Redeclaration of variable '%s'", name);
            return;
        }

        /* create new variable */
        KnownVar *kv = sem_add_var(name, SEM_TYPE_UNKNOWN);
        if (!kv)
        {
            sem_record_error(decl_node, "Failed to declare variable '%s'", name);
            return;
        }

        SEM_TEMP val = evaluate_expression(init_expr);

        // --- KUAN adopts RHS type, others keep declared type ---
        if (dtype == SEM_TYPE_UNKNOWN) // KUAN
        {
            kv->temp.type = val.type != SEM_TYPE_UNKNOWN ? val.type : SEM_TYPE_INT;
            kv->temp.type = kv->temp.type;
        }
        else
        {
            kv->temp.type = dtype;
            kv->temp.type = dtype;

            // force value conversion if needed
            if (dtype == SEM_TYPE_INT && val.type == SEM_TYPE_CHAR)
                val.int_value = (int)val.int_value;
            else if (dtype == SEM_TYPE_CHAR && val.type == SEM_TYPE_INT)
                val.int_value = (char)val.int_value;
        }

        kv->temp.is_constant = val.is_constant;
        kv->temp.int_value = val.is_constant ? val.int_value : 0;
        kv->initialized = 1;

        int idx = find_symbol(name);
        if (idx != -1)
        {
            symbol_table[idx].initialized = 1;
            if (kv->temp.type == SEM_TYPE_INT)
                snprintf(symbol_table[idx].value_str, SYMBOL_VALUE_MAX, "%ld", kv->temp.int_value);
            else if (kv->temp.type == SEM_TYPE_CHAR)
                snprintf(symbol_table[idx].value_str, SYMBOL_VALUE_MAX, "%c", (char)kv->temp.int_value);

            if (kv->temp.type == SEM_TYPE_INT)
                strcpy(symbol_table[idx].datatype, "ENTEGER");
            else
                strcpy(symbol_table[idx].datatype, "CHAROT");
        }
        return;
    }

    /* Otherwise recurse */
    handle_declaration(decl_node->left, dtype);
    handle_declaration(decl_node->right, dtype);
}


static void handle_assignment(ASTNode *assign_node)
{
    if (!assign_node || !assign_node->left)
        return;

    ASTNode *lhs = assign_node->left;
    ASTNode *rhs = assign_node->right;

    if (lhs->type != NODE_IDENTIFIER)
    {
        sem_record_error(assign_node, "Left-hand side of assignment must be an identifier");
        return;
    }

    const char *name = lhs->value;
    KnownVar *kv = sem_find_var(name);

    if (!kv)
    {
        // If variable not declared, create it
        kv = sem_add_var(name, SEM_TYPE_UNKNOWN);
    }

    // Evaluate RHS
    SEM_TEMP rhs_temp = evaluate_expression(rhs);

    // Determine old value
    long oldval = 0;
    if (kv->initialized)
        oldval = kv->temp.int_value;

    // Compute new value based on assignment type
    long newval = rhs_temp.is_constant ? rhs_temp.int_value : 0;
    const char *op = assign_node->value ? assign_node->value : "=";

    if      (strcmp(op, "+=") == 0) newval = oldval + rhs_temp.int_value;
    else if (strcmp(op, "-=") == 0) newval = oldval - rhs_temp.int_value;
    else if (strcmp(op, "*=") == 0) newval = oldval * rhs_temp.int_value;
    else if (strcmp(op, "/=") == 0)
    {
        if (rhs_temp.int_value == 0)
            sem_record_error(assign_node, "Division by zero");
        else
            newval = oldval / rhs_temp.int_value;
    }
    else if (strcmp(op, "=") == 0)
    {
        // simple assignment, just take RHS
        newval = rhs_temp.int_value;
    }
    else
    {
        sem_record_error(assign_node, "Unknown assignment operator '%s'", op);
        newval = oldval; // fallback
    }

    // Update variable
    kv->temp.int_value = newval;
    kv->temp.is_constant = 1;
    kv->initialized = 1;
    kv->used = 1;
    
    // Update symbol table
    int idx = find_symbol(name);
    if (idx != -1)
    {
        symbol_table[idx].initialized = 1;
        if (kv->temp.type == SEM_TYPE_INT)
            snprintf(symbol_table[idx].value_str, SYMBOL_VALUE_MAX, "%ld", newval);
        else if (kv->temp.type == SEM_TYPE_CHAR)
            snprintf(symbol_table[idx].value_str, SYMBOL_VALUE_MAX, "%c", (char)newval);
    }
}


/* ----------------------------
AST traversal
---------------------------- */

static void analyze_node(ASTNode *node)
{
    if (!node)
        return;
    switch (node->type)
    {
        case NODE_START: analyze_node(node->left); break;
        case NODE_STATEMENT_LIST:
            analyze_node(node->left);
            analyze_node(node->right);
            break;
        case NODE_STATEMENT:
            analyze_node(node->left);
            apply_deferred_ops(); // harmless (not used in current immediate semantics)
            break;
        case NODE_DECLARATION:
        {
            SEM_TYPE dtype = SEM_TYPE_UNKNOWN; // default to unknown, not INT
            if (node->value) {
                if (strcmp(node->value, "ENTEGER") == 0) dtype = SEM_TYPE_INT;
                else if (strcmp(node->value, "CHAROT") == 0) dtype = SEM_TYPE_CHAR;
                else if (strcmp(node->value, "KUAN") == 0) dtype = SEM_TYPE_UNKNOWN;
            }
            handle_declaration(node->left, dtype);
            apply_deferred_ops();
            break;
        }
            break;
        case NODE_ASSIGNMENT:
            handle_assignment(node);
            apply_deferred_ops();
            break;
        case NODE_PRINTING:
        case NODE_PRINT_ITEM:
            handle_print(node);
            apply_deferred_ops();
            break;
        default:
            evaluate_expression(node);
            break;
    }
}

/* ----------------------------
Check unused
---------------------------- */

static void check_unused_variables(void)
{
    for (KnownVar *k = known_vars_head; k; k = k->next)
    {
        ASTNode *node = k->temp.node;
        if (!k->used)
            sem_record_warning(node, "Variable '%s' declared but never use\n", k->name);
    }
}

/* ----------------------------
Semantic analyzer
---------------------------- */
int semantic_analyzer(void)
{
    // overwrite old file
    out_file = fopen("output_print.txt", "w");
    if (!out_file)
    {
        fprintf(stderr, "Failed to open output_print.txt\n");
        return 0;
    }

    sem_errors = 0;
    sem_warnings = 0;
    sem_next_temp_id = 1;
    sem_temps_count = 0;
    sem_ops_count = 0;
    print_offset = 0;
    print_buffer[0] = '\0';

    // free known vars
    KnownVar *k = known_vars_head;
    while (k)
    {
        KnownVar *n = k->next;
        free(k->name);
        free(k);
        k = n;
    }
    known_vars_head = NULL;

    if (!root)
    {
        fprintf(stderr, "No AST\n");
        fclose(out_file);
        return 0;
    }

    // Traverse AST
    analyze_node(root);

    // If errors exist, discard buffered prints
    if (sem_errors > 0)
    {
        print_offset = 0;
        print_buffer[0] = '\0';
    }
    else
    {
        // No errors: flush buffered prints
        if (print_offset > 0)
            fprintf(out_file, "%s", print_buffer);
    }

    if (sem_errors == 0)
    {
        // Write semantic analysis summary
        fprintf(out_file, "\n\n=== COMPILATION SUCCESSFULL ===\n\n");
        check_unused_variables();
        // fprintf(out_file, "[SEM] Analysis completed: %d semantic error(s), %d warning(s)\n", sem_errors, sem_warnings);
        fprintf(out_file, "\n%d semantic error(s), %d warning(s)\n", sem_errors, sem_warnings);
    }

    fclose(out_file);
    out_file = NULL;

    return sem_errors;
}

int semantic_error_count(void) { return sem_errors; }

void sem_cleanup(void)
{
    if (sem_temps)
    {
        free(sem_temps);
        sem_temps = NULL;
        sem_temps_count = 0;
        sem_temps_capacity = 0;
    }
    if (sem_ops)
    {
        free(sem_ops);
        sem_ops = NULL;
        sem_ops_count = 0;
        sem_ops_capacity = 0;
    }
    KnownVar *k = known_vars_head;
    while (k)
    {
        KnownVar *n = k->next;
        free(k->name);
        free(k);
        k = n;
    }
    known_vars_head = NULL;

    DeferredOp *d = deferred_head;
    while (d)
    {
        DeferredOp *n = d->next;
        free(d);
        d = n;
    }
    deferred_head = NULL;

    sem_errors = 0;
    sem_warnings = 0;
}
